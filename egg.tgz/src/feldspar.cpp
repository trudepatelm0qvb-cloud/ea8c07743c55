// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("feldspar"); }
int main(){
  announce();
  return lionss_run_workload("feldspar");
}
