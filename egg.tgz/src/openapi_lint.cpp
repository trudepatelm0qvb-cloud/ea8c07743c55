// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("openapi_lint\n", stdout);
  return lionss_run_workload("openapi_lint");
}
