// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("NavMeshBake\n", stdout);
  return lionss_run_workload("NavMeshBake");
}
