// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("I2cRecover\n", stdout);
  return lionss_run_workload("I2cRecover");
}
