// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("pitchShift2x\n", stdout);
  return lionss_run_workload("pitchShift2x");
}
