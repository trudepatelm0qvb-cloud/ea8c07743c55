// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("stress_soak"); }
int main(){
  announce();
  return lionss_run_workload("stress_soak");
}
