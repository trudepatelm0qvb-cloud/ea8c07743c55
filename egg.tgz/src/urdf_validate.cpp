// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("urdf_validate\n", stdout);
  return lionss_run_workload("urdf_validate");
}
