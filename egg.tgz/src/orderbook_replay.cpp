// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("orderbook_replay"); }
int main(){
  announce();
  return lionss_run_workload("orderbook_replay");
}
