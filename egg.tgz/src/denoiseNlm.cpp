// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("denoiseNlm"); }
int main(){
  announce();
  return lionss_run_workload("denoiseNlm");
}
