// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("ocsp staple\n", stdout);
  return lionss_run_workload("ocsp-staple");
}
