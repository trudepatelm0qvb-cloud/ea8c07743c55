// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("prometheus_scrape"); }
int main(){
  announce();
  return lionss_run_workload("prometheus_scrape");
}
