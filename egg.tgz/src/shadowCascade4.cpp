// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("shadowCascade4\n", stdout);
  return lionss_run_workload("shadowCascade4");
}
