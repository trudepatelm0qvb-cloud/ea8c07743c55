// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("colorGamutP3\n", stdout);
  return lionss_run_workload("colorGamutP3");
}
